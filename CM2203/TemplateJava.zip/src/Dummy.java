import io.vavr.Function2;
import io.vavr.Function3;

import java.util.*;
import java.util.function.Function;

// If for some reason you have not completed Task 1 or Task 2 but can completed Task 3, feel free to use the following
// dummy functions.
public class Dummy {

    public static ArrayList<String[]> kNN(ArrayList<String[]> trainingData, Integer k, Function2<Object, Object, Float> measureFunction,
                                          Boolean similarityFlag, ArrayList<String[]> dataToClassify, Function<Map<String, Integer>, String> mostCommonClassFunc,
                                          Function3<List<Pair<Float, String>>, Integer, Boolean, Map<String, Integer>> getKNeighboursClassesFunc,
                                          Function<String, Object> readFunction) {
        ArrayList<String[]> classifiedData = new ArrayList<String[]>();
        classifiedData.add(new String[]{"Path", "ActualClass", "PredictedClass"});
        for (int i = 1; i < dataToClassify.size(); i++) {
            //this is only a dummy function, we default classification to Food
            ArrayList<String> newRow = new ArrayList<>();
            Collections.addAll(newRow, dataToClassify.get(i));
            newRow.add("Food");
            classifiedData.add(newRow.toArray(new String[newRow.size()]));
        }
        System.out.println("Running dummyKNN");
        return classifiedData;
    }


    public static HashMap<String, Float> dummyEvaluateKNN(ArrayList<String[]> classifiedData, Function<ArrayList<String[]>, int[][]> confusionMatrixFunction) {
        HashMap<String, Float> result = new HashMap<>();
        // once ready, we return the values
        result.put("Precision", 2.0F);
        result.put("Recall", 2.0F);
        result.put("F-measure", 2.0F);
        result.put("Accuracy", 2.0F);
        return result;
    }
}
