import java.io.*;
import java.util.ArrayList;
import java.util.Objects;

// This code has been taken from https://stackabuse.com/reading-and-writing-csvs-in-java/

public class SimpleCSVParser{
    // Straightforward function to read the data contained in the file at pathToCsv

    public static ArrayList<String[]> readCSV(String pathToCsv) throws IOException {
        ArrayList<String[]> answer = new ArrayList<String[]>();
        if(Objects.isNull(pathToCsv) || pathToCsv.isEmpty()){
            System.err.println("No pathToCsv provided to read");
            return answer;
        }
        File csvFile = new File(pathToCsv);
        if (csvFile.isFile()) {
            BufferedReader csvReader = new BufferedReader(new FileReader(csvFile));
            String row;
            while ((row = csvReader.readLine()) != null) {
                String[] data = row.split(",");
                answer.add(data);

            }
            csvReader.close();
        }
        else{
            System.err.println("File not found: " + pathToCsv + ". Please double check things!");
        }
        return answer;
    }
    // Straightforward function to write the data contained in data to a csv file at filePath
    public static void writeCSV(ArrayList<String[]> data, String filePath) throws IOException {
       FileWriter csvWriter = new FileWriter(filePath);

        for (String[] row : data) {
            csvWriter.append(String.join(",", row));
            csvWriter.append("\n");
        }

        csvWriter.flush();
        csvWriter.close();
    }

}