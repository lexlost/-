
/*
  In this file please complete the following tasks:

Task 1 [10] My first not-so-pretty image classifier

By using the kNN approach and three distance or similarity measures, build image classifiers.
•	You must implement the kNN approach yourself
•	You must invoke the distance or similarity measures from libraries (it is fine to invoke different measures
from one library). Non-trivial adjustments to a library-invoked measure do not meet the requirements!
•	Histogram-based measures are not allowed
•	Jaccard distances/similarities are not allowed
•	You can use between 0 and 3 distance measures and between 0 and 3 similarity measures (there is no requirement
that at least one of each kind should be present)

The classifier is expected to use only one measure at a time and take information as to which one to invoke at a given
time as input. The template contains a range of functions you must implement and use appropriately for this task.

You can start working on this task immediately. Please consult at the very least Week 2 materials.

Task 5 [4] Similarities

Independent inquiry time! In Task 1, you were instructed to use libraries for image similarity measures.
Pick two of the three measures you have used and implement them yourself. You are allowed to use libraries to e.g.,
calculate the root, power, average or standard deviation of some set (but, for example, numpy.linalg.norm is
not permitted). The template contains a range of functions you need to implement for this task.

Disclaimer: if you decide to implement MSE, do not implement RMSE (and vice versa)

You can start working on this task immediately. Please consult at the very least Week 1 materials.


  */


import io.vavr.Function2;
import io.vavr.Function3;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

public class Task_1_5 {
    static int width = 60;
    static int height = 30;
    
    // Please replace with your student id!!!
    public static String studentID = "insert_id_here";
    
    // This is the classification scheme you should use for kNN
    static String[] classificationScheme = {"Female", "Male", "Primate", "Rodent", "Food"};
    
    /* In this function, please implement validation of the data that is supplied to or produced by the kNN classifier.

     INPUT:
         data        : ArrayList that was read from the training data csv OR data to classify csv OR produced by the kNN function
         predicted   : a boolean value stating whether the "PredictedClass" column should be present

     OUTPUT:
         boolean value
                     : True if the data contains the header ["Path", "ActualClass"] if predicted variable is False
                     and ["Path", "ActualClass", "PredictedClass"] if it is True
                     (there can be more column names, but at least these three at the start must be present)
                     AND the values in the "Path" column (if there are any) are file paths
                     AND the values in the "ActualClass" column (if there are any) are classes from scheme
                     AND (if predicted is True) the values in the "PredictedClass" column (if there are any)
                     are classes from scheme
                     AND there are as many Path entries as ActualClass (and PredictedClass, if predicted
                     is True) entries
                     False otherwise
     */
    static public Boolean validateDataFormat(ArrayList<String[]> data, Boolean predicted) {
        boolean formatCorrect = false;
        
        return formatCorrect;
    }
    /*This function does reading and resizing of an image located in a give path on your drive.

    DO NOT REMOVE ANY COLOURS. DO NOT MODIFY PATHS. DO NOT FLATTEN IMAGES.
    USE DEFAULT WIDTH AND HEIGHT VALUES (see statics defined above)
    
    INPUT:  imagePath         : path to image. DO NOT MODIFY - take from the file as-is. Things like appending "..\"
                                to the file path within the code are not permitted.
    OUTPUT: image             : read and resized image in RGB format, or null if the image is not found at a given path.
                                The choice of actual class is up to you, you will need to recast it to the chosen
                                image class. Removing colour channels (e.g. transforming array to grayscale) or
                                flattening the image ARE NOT PERMITTED.
    */
    
    static public Object readAndResize(String image_path) {
        
        
        return null;
    }
    
    /* These functions compute the distance or similarity value between two images according to a particular
    similarity or distance measure. Return nan if images are empty. These three measures must be
    computed by libraries according to portfolio requirements. Do NOT presume a particular height or width!
    If you need images flattened or in grayscale or in any other format, then these manipulations will need to take
    place WITHIN the computeMeasure functions.

    INPUT:  image1, image2    : two images to compare

    OUTPUT: value             : the distance or similarity value between image1 and image2 according to a chosen approach.
                                Defaults to nan if images are empty.

*/
    static public Float computeMeasure1(Object image1, Object image2) {
        //Write here what kind of measure you are using!
        float value = Float.NaN;
        
        return value;
    }
    
    static public Float computeMeasure2(Object image1, Object image2) {
        //Write here what kind of measure you are using!
        float value = Float.NaN;
        
        return value;
    }
    
    static public Float computeMeasure3(Object image1, Object image2) {
        //Write here what kind of measure you are using!
        float value = Float.NaN;
        
        return value;
    }
    /*These functions compute the distance or similarity value between two images according to a particular similarity or
    distance measure. Return nan if images are empty. As name suggests, selfComputeMeasure 1 has to be your own
    implementation of the measure you have used in computeMeasure1 (same for 2). These two measures cannot be
    computed by libraries according to portfolio requirements. Do NOT presume a particular height or width! If you
    need images flattened or in grayscale or in any other format, then these manipulations will need to take place
    WITHIN the computeMeasure functions.
    
    INPUT:  image1, image2    : two images to compare
    
    OUTPUT: value             : the distance or similarity value between image1 and image2 according to a chosen approach.
                                Defaults to nan if images are empty.
    
    */
    
    static public Float selfComputeMeasure1(Object image1, Object image2) {
        //Write here what kind of measure you are using!
        float value = Float.NaN;
        
        return value;
    }
    
    static public Float selfComputeMeasure2(Object image1, Object image2) {
        //Write here what kind of measure you are using!
        float value = Float.NaN;
        
        return value;
    }
    
    /*This function is supposed to return a map of classes and their occurrences as taken from k nearest neighbours.

    INPUT:  measure_classes   : a list of pairs, where each pair is a distance/similarity value
                            and class from scheme
        k                 : the value of k neighbours
        similarity_flag   : a boolean value stating that the measure used to produce the values above is a distance
                            (False) or a similarity (True)
    OUTPUT: nearest_neighbours_classes
                          : a map that, for each class in the scheme, states how often this class
                            was in the k nearest neighbours
    */
    static public Map<String,Integer> getClassesOfKNearestNeighbours(List<Pair<Float,String>> measures_classes, Integer k, Boolean similarityFlag) {
        Map<String,Integer> nearest_neighbours_classes = null;
        
        return nearest_neighbours_classes;
    }

    /* Given a dictionary of classes and their occurrences, returns the most common class. In case there are multiple
     candidates, it follows the order of classes in the scheme. The function returns empty string if the input dictionary
     is empty, does not contain any classes from the scheme, or if all classes in the scheme have occurrence of 0.
    
     INPUT: nearest_neighbours_classes
                               : a map that, for each class in the scheme, states how often this class
                                 was in the k nearest neighbours
    
     OUTPUT: winner            : the most common class from the classification scheme. In case there are
                                 multiple candidates, it follows the order of classes in the scheme. Returns empty string
                                 if the input map is empty, does not contain any classes from the scheme,
                                 or if all classes in the scheme have occurrence of 0
    */
    
    static String getMostCommonClass(Map<String,Integer> nearest_neighbours_classes) {
        String winner = "";
        
        return winner;
    }
    /*In this function I expect you to implement the kNN classifier. You are free to define any number of helper functions
     you need for this!

    INPUT:      trainingData    : ArrayList that was read from the training data csv
                k               : the value of k neighbours
                measureFunction : the function to be invoked to calculate similarity/distance (any of the above)
                similarityFlag  : a boolean value stating that the measure above used to produce the values is a distance
                                 (False) or a similarity (True)
                dataToClassify  : ArrayList that was read from the data to classify csv;
                                     this data is NOT be used for training the classifier, but for running and testing it
         mostCommonClassFunc    : the function to be invoked to find the most common class among the neighbours
                                 (by default, it is the one from above)
     getKNeighboursClassesFunc  : the function to be invoked to find the classes of nearest neighbours
                                 (by default, it is the one from above)
             readFunction       : the function to be invoked to find to read and resize images
                                 (by default, it is the one from above)
            validationFunction  : the function to be invoked to find validate the input/output csv files
                                 (by default, it is the one from above)
    OUTPUT: classifiedData      : ArrayList which expands the dataToClassify with the results on how your
                                 classifier has classified a given image
                                 IF the training_data or data_to_classify is empty OR
#                                training_data, data_to_classify, or produced classified_data fail validation,
#                                the returned ArrayList contains ONLY the header row
    */
    
    public static ArrayList<String[]> kNN(ArrayList<String[]> trainingData, Integer k, Function2<Object,Object,Float> measureFunction,
                                          Boolean similarityFlag, ArrayList<String[]> dataToClassify, Function<Map<String,Integer>,String> mostCommonClassFunc,
                                          Function3<List<Pair<Float,String>>, Integer,Boolean,Map<String,Integer> > getKNeighboursClassesFunc,
                                          Function<String, Object> readFunction) {
        ArrayList<String[]> classifiedData = new ArrayList<String[]>();
        //adds a header to the ArrayList we want to return
        classifiedData.add(new String[]{"Path", "ActualClass", "PredictedClass"});
        //    Have fun!
        System.out.println("Running kNN");
        //
        return classifiedData;
    }

    /*
    ******************************************************************************************
    * You should not need to modify things below this line - it's mostly reading and writing *
    * Be aware that error handling below is...limited.                                       *
    ******************************************************************************************

    This function reads the necessary arguments (see Parameters class) and based on them executes
    the kNN classifier. If the u flag is on, the results are written to a file.

    */
    
    public static void main(String[] args) {
        // handle arguments
        Parameters params = new Parameters(args);
        ArrayList<String[]> trainingData = new ArrayList<String[]>();
        ArrayList<String[]> dataToClassify = new ArrayList<String[]>();
        
        System.out.println("Reading data from " + params.getTrainingDataPath() + " and " + params.getDataToClassifyPath());
        try {
            trainingData = SimpleCSVParser.readCSV(params.getTrainingDataPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            dataToClassify = SimpleCSVParser.readCSV(params.getDataToClassifyPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(Objects.isNull(dataToClassify)|| Objects.isNull(trainingData) ||dataToClassify.isEmpty() ||trainingData.isEmpty() ||Objects.isNull(params.similarityFlag) || Objects.isNull(params.getMeasureFunction())){
            System.err.println("Hey, some of the things for kNN are missing! Can't do stuff without it T_T");
            return;
        }
        
        System.out.println("Running kNN");
        ArrayList<String[]> result = Task_1_5.kNN(trainingData, params.getK(), params.getMeasureFunction(), params.similarityFlag, dataToClassify,params.getMcc(),params.getGnc(),params.getRrf());
        if (params.isU()) {
            String folder = null;
            try {
                folder = Paths.get(params.getDataToClassifyPath()).getParent().toRealPath().toString();
            } catch (IOException e) {
                e.printStackTrace();
            }
            String out = folder+"/"+studentID+"_classified_data.csv";
            System.out.println("Writing data to " + out);
            try {
                SimpleCSVParser.writeCSV(result,out);
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("Writing to " + out + " failed! OH NOES!");
            }
        }
        System.out.println("Finished");
    }
    
}
