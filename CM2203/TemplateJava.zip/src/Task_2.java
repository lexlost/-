/*
In this file please complete the following task:

Task 2 [4] Basic evaluation

Evaluate your classifiers. On your own, implement a method that will create a confusion matrix based on the provided
classified data. Then implement methods that will output precision, recall, F-measure, and accuracy of your classifier
based on your confusion matrix. Use macro-averaging approach and be mindful of edge cases. The template contains
a range of functions you need to implement for this task.

You can start working on this task immediately. Please consult at the very least Week 3 materials.

You are expected to rely on solutions from Task_1_5 here! Do not reimplement kNN from scratch. You can ONLY rely
on functions that were originally in the template in your final submission! Any functions you have created on your
own and need here, must be defined here.

*/

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.function.Function;

public class Task_2 {

    /*
     This function computes the confusion matrix based on the provided data.
    
     INPUT: classified_data   : ArrayList where each entry consists of path to images, actual classes and predicted classes.
                                Please refer to Task 1 for precise format description.
     OUTPUT: confusion_matrix : the confusion matrix computed based on the classified_data. The order of elements needs
                                to be the same as  in the classification scheme. The columns correspond to actual classes
                                and rows to predicted classes. In other words, confusion_matrix[0][1] corresponds to an entry
                                where predicted class is Female but actual class is male.
    */
    
    public static int[][] confusionMatrix(ArrayList<String[]> classified_data) {
        int[][] confusion_matrix = null;
        return confusion_matrix;
    }


    /*
     These functions compute per-class true positives and false positives/negatives based on the provided confusion matrix.
    
     INPUT: confusion_matrix : the confusion matrix computed based on the classified_data. The order of elements is
                               the same as  in the classification scheme. The columns correspond to actual classes
                               and rows to predicted classes.
     OUTPUT: an array of appropriate true positive, false positive or false
             negative values per a given class, in the same order as in the classification scheme. For example, tps[1]
             corresponds for TPs for Male class.
    */
    
    public static int[] computeTPs(int[][] confusion_matrix){
        int[] tps = null;
        return tps;
    }
    
    public static int[] computeFPs(int[][] confusion_matrix){
        int[]fps = null;
        return fps;
    }
    
    
    public static int[] computeFNs(int[][] confusion_matrix){
        int[] fns = null;
        return fns;
    }

    /* These functions compute the evaluation measures based on the provided values. Not all measures use of all the values.
    
     INPUT: tps, fps, fns, data_size
                           : the per-class true positives, false positive and negatives, and size of the classified data.
     OUTPUT: appropriate evaluation measures created using the macro-average approach.
    */
    
    public static float computeMacroPrecision(int[] tps,int[] fps,int[] fns, int data_size){
        float precision = 0;
        return precision;
    }
    
    public static float computeMacroRecall(int[] tps,int[] fps,int[] fns, int data_size){
        float recall = 0;
        return recall;
    }
    
    public static float  computeMacroFMeasure(int[] tps,int[] fps,int[] fns, int data_size){
        float f_measure = 0;
        return f_measure;
    }
    
    public static float computeAccuracy(int[] tps,int[] fps,int[] fns, int data_size){
        float accuracy = 0;
        return accuracy;
    }
    
    /*
      In this function you are expected to compute precision, recall, f-measure and accuracy of your classifier using
      the macro average approach.
    
     INPUT:     classified_data   : ArrayList where each entry consists of path to images, actual classes and predicted classes.
                                    Please refer to Task 1 for precise format description.
        confusionMatrixFunction   : function to be invoked to compute the confusion matrix
    
      OUTPUT: hashmap of computed measures
     */
    public static HashMap<String, Float> evaluateKNN(ArrayList<String[]> classifiedData, Function<ArrayList<String[]>,int[][]> confusionMatrixFunction) {
        HashMap<String, Float> result = new HashMap<>();
        float precision = -1;
        float recall = -1;
        float fMeasure = -1;
        float accuracy = -1;
        //Have fun with the computations !
        
        
        // once ready, we return the values
        result.put("Precision",precision);
        result.put("Recall", recall);
        result.put("F-measure",fMeasure);
        result.put("Accuracy", accuracy);
        return result;
    }

      /*
    ******************************************************************************************
    * You should not need to modify things below this line - it's mostly reading and writing *
    * Be aware that error handling below is...limited.                                       *
    ******************************************************************************************

    This function reads the necessary arguments (see Parameters class) and based on them evaluates the kNN classifier.
    */
    
    public static void main(String[] args) {
        // handle arguments
        Parameters params = new Parameters(args);
        ArrayList<String[]> classifiedData = new ArrayList<String[]>();
        
        System.out.println("Reading data from " + params.getClassifiedPath());
        try {
            classifiedData = SimpleCSVParser.readCSV(params.getClassifiedPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        if(Objects.isNull(classifiedData)||classifiedData.isEmpty()){
            System.err.println("Hey, some of the things for kNN evaluation are missing! Can't do stuff without it T_T");
            return;
        }
        System.out.println("Running kNN evaluation");
        HashMap<String, Float> result = Task_2.evaluateKNN(classifiedData,params.getConfusionMatrixFunction());
        System.out.println(result.toString());
        System.out.println("Finished");
    }
    
}
