/*
In this file please complete the following task:

Task 3 [6] Cross validation

Evaluate your classifiers using the k-fold cross-validation technique covered in the lectures
(use the training data only). Output their average precisions, recalls, F-measures and accuracies.
You need to implement the validation yourself. Remember that folds need to be of roughly equal size.
The template contains a range of functions you need to implement for this task.

You can start working on this task immediately. Please consult at the very least Week 3 materials.

You are expected to rely on solutions from Task_1_5/Task_2 here! Do not reimplement kNN from scratch.
You can ONLY rely on functions that were originally in the template in your final submission!
Any functions you have created on your own in these files and need here, must be defined here.
*/

import io.vavr.Function2;
import io.vavr.Function3;
import io.vavr.Function8;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Function;

public class Task_3 {
    
    /*
    This function takes the data for cross evaluation and returns training_data a list of lists s.t. the first element
    is the round number, second is the training data for that round, and third is the testing data for that round

    INPUT: training_data      : ArrayList that was read from the training data csv
           f                  : the number of folds to split the data into (which is also same as # of rounds)
    OUTPUT: folds             : a map that to each round value assigns a pair of training data and testing data for that round
                                You must make sure that the training and testing data are ready for use
                                (e.g. contain the right headers already)
   */
    public static Map<Integer, Pair<ArrayList<String[]>,ArrayList<String[]>>> splitDataForCrossValidation(ArrayList<String[]> training_data, Integer f) {
        Map<Integer, Pair<ArrayList<String[]>,ArrayList<String[]>>> folds = null;
        return folds;
    }
    
    /*
     In this function, please implement validation of the data that is produced by the cross evaluation function PRIOR to
     the addition of rows with the average measures.
    
     INPUT:  data              : ArrayList that was produced by the crossEvaluateKNN function BEFORE the
#                               addition of the measures
             f                 : number of folds to validate against
    
     OUTPUT: boolean value     : True if the data contains the header ["Path", "ActualClass", "FoldNumber", "PredictedClass"]
                                 (there can be more column names, but at least these four at the start must be present)
                                 AND the values in the "Path" column (if there are any) are file paths
                                 AND the values in the "ActualClass" and "PredictedClass" columns
                                 (if there are any) are classes from the scheme
                                 AND the values in the "FoldNumber" column are integers in [0,f) range
                                 AND there are as many Path entries as ActualClass and PredictedClass and FoldNumber entries
                                 AND the number of entries per each integer in [0,f) range for FoldNumber are approximately
                                 the same (they can differ by at most 1)
    
                                 False otherwise
    */
    public static boolean validateDataFormat(ArrayList<String[]> data, int f){
        boolean formatCorrect = false;
        
        return formatCorrect;
    }
    
    /*
     This function takes the classified data from each cross validation round and calculates the average precision, recall,
     accuracy and f-measure for them.
     Input either the Task 2 evaluation function or the dummy function here, do not code from scratch!
    
     INPUT: classified_data_list
                               : a map that assigns to a round number the classified data computed for that cross validation round
            evaluation_func    : the function to be invoked for the evaluation (use either the one from
                                 Task_2 or dummy)
     OUTPUT: hashmap of computed average measures. You are expected to evaluate every classified data in the
                                 input map and average out these values in the usual way.
    */
    public HashMap<String, Float> evaluateCrossValidation(HashMap<Integer,ArrayList<String[]>> classifiedData,
                                                          Function2<ArrayList<String[]>,Function<ArrayList<String[]>,int[][]>,HashMap<String, Float>> evaluationFunction) {
        HashMap<String, Float> result = new HashMap<>();
        float precision = -1;
        float recall = -1;
        float fMeasure = -1;
        float accuracy = -1;
        //Have fun with the computations !
        
        
        // once ready, we return the values
        result.put("Precision",precision);
        result.put("Recall", recall);
        result.put("F-measure",fMeasure);
        result.put("Accuracy", accuracy);
        return result;
    }

    /*
     In this task you are expected to perform cross-validation where f defines the number of folds to consider.
     "processed" holds the information from training data along with the following information: for each image,
     stated the id of the fold it landed in, and the predicted class it was assigned once it was chosen for testing data.
     After everything is done, we add the average measures at the end. The writing to csv is done in a different function.
     You are expected to invoke the Task 1 kNN classifier or the dummy classifier here, do not implement these things
     from scratch!
    
     INPUT: training_data      : ArrayList that was read from the training data csv
                k              : the value of k neighbours
             measureFunction   : the function to be invoked to calculate similarity/distance (any of the above)
            similarityFlag     : a boolean value stating that the measure above used to produce the values is a distance
                                 (False) or a similarity (True)
            knnFunction        : the function to be invoked for the classification (by default, it is the one from
                                 Task_1_5, but you can use dummy)
            splitFunction      : the function used to split data for cross validation (by default, it is the one above)
            f                  : number of folds to use in cross validation
     OUTPUT: processed         : ArrayList which expands the training_data with columns stating the fold number to
                                 which a given image was assigned and the predicted class for that image; and with rows
                                 that contain the average evaluation measures
                                 IF validation of the processed variable fails (prior to addition of evaluation measures),
#                                return only the header!
     Again, please remember to have a look at the Dummy file!
    */
    
    public static ArrayList<String[]> crossEvaluateKNN(ArrayList<String[]> trainingData, int k, Function2<Object,Object,Float> measureFunction,boolean similarityFlag, int f,
                                                       Function8<ArrayList<String[]>,Integer, Function2<Object,Object,Float>,
                                                               Boolean, ArrayList<String[]>, Function<Map<String,Integer>,String>,
                                                               Function3<List<Pair<Float,String>>, Integer,Boolean,Map<String,Integer>>,
                                                               Function<String, Object>,ArrayList<String[]>> knnFunction,
                                                       Function2<ArrayList<String[]>, Integer ,Map<Integer, Pair<ArrayList<String[]>,ArrayList<String[]>>>> splitFunction) {
        ArrayList<String[]> processed = new ArrayList<String[]>();
        processed.add(new String[]{"Path", "ActualClass", "PredictedClass","FoldNumber"});
        // Have fun!
        
        //Once folds are ready and you have the respective measures, please calculate the averages:
        float avg_precision = -1;
        float avg_recall = -1;
        float avg_fMeasure = -1;
        float avg_accuracy = -1;
        //Have fun with the computations !
        
        // The measures are now added to the end. You should invoke validation BEFORE this step.
        processed.add(new String[]{"avg_precision", "avg_recall", "avg_fmeasure", "avg_accuracy"});
        processed.add(new String[]{String.valueOf(avg_precision), String.valueOf(avg_recall),
                String.valueOf(avg_fMeasure),String.valueOf(avg_accuracy)});
        return processed;
    }

      /*
    ******************************************************************************************
    * You should not need to modify things below this line - it's mostly reading and writing *
    * Be aware that error handling below is...limited.                                       *
    ******************************************************************************************

    This function reads the necessary arguments (see Parameters class) and based on them evaluates the kNN classifier.
    */
    
    public static void main(String[] args) {
        // handle arguments
        Parameters params = new Parameters(args);
        ArrayList<String[]> trainingData = new ArrayList<String[]>();
        
        System.out.println("Reading data from " + params.getTrainingDataPath());
        try {
            trainingData = SimpleCSVParser.readCSV(params.getTrainingDataPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(Objects.isNull(trainingData) ||trainingData.isEmpty()|| params.getK()<=0||Objects.isNull(params.similarityFlag) || Objects.isNull(params.getMeasureFunction()) || params.getF()<=0){
            System.err.println("Hey, some of the things for cross validating kNN are missing! Can't do stuff without it T_T");
            return;
        }
        
        System.out.println("Running cross kNN evaluation");
        ArrayList<String[]> result = Task_3.crossEvaluateKNN(trainingData, params.getK(), params.getMeasureFunction(), params.similarityFlag, params.getF(), params.getKnnFunction(),params.getSf());
        String folder = null;
        try {
            folder = Paths.get(params.getTrainingDataPath()).getParent().toRealPath().toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String out = folder+"/"+Task_1_5.studentID+"_cross_validation.csv";
        System.out.println("Writing data to " + out);
        try {
            SimpleCSVParser.writeCSV(result,out);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Writing to " + out + " failed! OH NOES!");
        }
        System.out.println("Finished");
    }
    
}

