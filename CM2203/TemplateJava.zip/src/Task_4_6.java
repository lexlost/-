/*
In this file please complete the following tasks:

Task 4 [3] The curse of k

Independent inquiry time! Picking the right number of neighbours k in the kNN approach is tricky.
Find a way you could approach this more rigorously. In comments:
•	state the name of the approach you could use,
•	give a one-sentence explanation of the approach, and
•	provide a reference to it (use Cardiff University Harvard style, DOI MUST BE PRESENT).

The reference must be a handbook or peer-reviewed publication; a link to an online tutorial will not be accepted.
Ensure that your resources are respectable and are not e.g., predatory journals.

You can start working on this task immediately. Please consult at the very least Week 2 materials.

*/

/*
Task 6 [3] I can do better!

Independent inquiry time! There are much better approaches out there for image classification.
Your task is to find one, and using the comment section of your project, do the following:
•	State the name of the approach
•	Provide a permalink to a resource in the Cardiff University library that describes the approach
•	Briefly explain how the approach you found is better than kNN in image classification (2-3 sentences is enough).
Focus on synthesis, not recall!

You can start working on this task immediately. Please consult at the very least Week 2 materials.

*/

public class Task_4_6 {
    //no coding required, leave this empty :)
}
