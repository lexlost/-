public class DiningPhilosophers {

    public static void main(String[] args) throws Exception {
        
        final int problemSize=5;
        final boolean reportingRequired=true;
        // Whether inidividual Philosopher acts are to be reported to standard
        // output stream
        final boolean reportEatCounts=false;
        // Whether the eat counts are periodically to be reported
        // (for later parts of the task)
        int leftForkNumber;
        int rightForkNumber;

        Philosopher[] philosophers = new Philosopher[problemSize];
        Fork[] forks = new Fork[problemSize];

        for (int i = 0; i < problemSize; i++) {
            forks[i] = new Fork();
        }

        for (int i = 0; i < problemSize; i++) {
            leftForkNumber = i;
            rightForkNumber = (i + 1) % problemSize;

            philosophers[i] = new Philosopher(leftForkNumber, rightForkNumber, i+1, forks, reportingRequired);
            
            Thread t = new Thread(philosophers[i]);
            t.start();
        }
    }
}
