public class Fork {
    public volatile boolean inUse=false;
    // It might be useful for this to be volatile for your "lock object"-based
    // solution
}
