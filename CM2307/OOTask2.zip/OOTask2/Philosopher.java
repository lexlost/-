public class Philosopher implements Runnable {
    // The forks on either side of this Philosopher and his/her philosopher number
    private int leftForkNumber;
    private int rightForkNumber;
    private int philosopherNumber;
    private Fork[] theForks;
    private boolean reporting;
    // Whether actions are to be logged to the standard output stream

    public Philosopher(int left, int right, int philNumber,
                       Fork[] theForkArray, boolean reportingRequired) {
        leftForkNumber = left;
        rightForkNumber = right;
        philosopherNumber=philNumber;
        theForks=theForkArray;
        reporting=reportingRequired;
    }
    
	private void doAction(String action) throws InterruptedException {
        if (reporting)
          System.out.println("Philosopher number " + philosopherNumber
                             + " time: " + System.nanoTime() + ": " + action);
        Thread.sleep(((int) (Math.random() * 100)));
    }

    public void run() {
        try {
            while (true) {
                
                // thinking
                doAction("Thinking");
                synchronized (theForks[leftForkNumber]) {
                    theForks[leftForkNumber].inUse=true;
                    doAction("Picking up left fork");
                    synchronized (theForks[rightForkNumber]) {
                        // eating
                        theForks[rightForkNumber].inUse=true;
                        doAction("Picking up right fork"); 
                        doAction("Eating");
                        doAction("Putting down right fork");
                        theForks[rightForkNumber].inUse=false;
                    }
                    // Back to thinking
                    doAction("Putting down left fork");
                    theForks[leftForkNumber].inUse=false;
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
    }
}
